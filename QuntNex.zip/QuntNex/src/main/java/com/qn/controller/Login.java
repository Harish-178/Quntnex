package com.qn.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qn.model.Customer;
import com.qn.model.Register;
public class Login extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username	=request.getParameter("username");
		String password=request.getParameter("password");
		
	 Register r=new Register();
	r.setUsername(username);
	r.setPassword(password);
	int status=r.QuntNexLogin();
	if(status==1) {
		response.sendRedirect("/QuntNex/loginsuccess.jsp");
		
	}
	else if (status==-1) {
		response.sendRedirect("/QuntNex/invalidusername.jsp");
		
	}
	else {
		response.sendRedirect("/QuntNex/invalidpassword.jsp");

	}
			
		
			}
	}
